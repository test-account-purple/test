
#import <stdio.h>
#import <unistd.h>
int main()
{
    printf("Hello\n");
    sleep(20);
    printf("Don't run random binaries!\n");
    return 0;
}
