#!/bin/bash

echo "backdoor-ed" > backdoor.txt
